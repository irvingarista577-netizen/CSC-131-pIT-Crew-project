package com.scheduler;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BookingController {

    public String bookAppointment(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String time) {

        System.out.println("NEW BOOKING:");
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Time: " + time);

        return "home";
    }
}